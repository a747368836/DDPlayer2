package mvp.bilibililike.player.ui.bangumi

import BasePresenter


class bangumiPresenter(view: bangumiContract.View) : BasePresenter<bangumiContract.View>(view), bangumiContract.Presenter