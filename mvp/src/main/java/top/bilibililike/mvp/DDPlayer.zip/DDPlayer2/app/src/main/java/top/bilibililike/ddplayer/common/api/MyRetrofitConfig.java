package top.bilibililike.ddplayer.common.api;

import com.zhan.mvp.http.BaseRetrofitConfig;

import org.jetbrains.annotations.NotNull;

public class MyRetrofitConfig extends BaseRetrofitConfig {
    @NotNull
    @Override
    public String getBaseUrl() {
        return Api.API_HOST;
    }
}
