package mvp.bilibililike.player.ui.bangumi



import MVPActivity
import mvp.bilibililike.player.R



class bangumiActivity : MVPActivity<bangumiContract.Presenter>(), bangumiContract.View {

    override fun getLayoutId(): Int = R.layout.activity_bangumi

    override fun bindPresenter(): bangumiContract.Presenter = bangumiPresenter(this)
}