package mvp.bilibililike.player.common.bean

