package mvp.bilibililike.player.ui.bangumi

import com.zhan.mvp.mvp.BaseContract



interface bangumiContract {

    interface View : BaseContract.View

    interface Presenter : BaseContract.Presenter
}
