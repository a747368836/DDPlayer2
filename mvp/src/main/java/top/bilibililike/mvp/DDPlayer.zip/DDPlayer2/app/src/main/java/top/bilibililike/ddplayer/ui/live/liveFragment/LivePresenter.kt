package mvp.bilibililike.player.ui.live.liveFragment

import com.zhan.mvp.mvp.BaseContract
import com.zhan.mvp.mvp.BasePresenter

class LivePresenter : ILivePresenter {
    override fun getLivers(roomId: Array<String>) {

    }

    override fun detachView() {

    }

    override fun showError(msg: String) {

    }

    override fun showError(strRes: Int) {

    }

    override fun showLoading() {

    }
}
