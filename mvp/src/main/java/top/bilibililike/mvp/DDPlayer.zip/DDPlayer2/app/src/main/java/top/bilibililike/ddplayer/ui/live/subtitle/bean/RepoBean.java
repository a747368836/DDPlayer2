package top.bilibililike.ddplayer.ui.live.subtitle.bean;

import java.util.List;

public class RepoBean {


    /**
     * code : 0
     * message : 0
     * ttl : 1
     * data : {"room_info":{"uid":443305053,"room_id":21560356,"short_id":0,"title":"只狼peko","cover":"http://i0.hdslb.com/bfs/live/new_room_cover/08e1b57d53d3f2ae7f1fcccfe0aafcff065f16aa.jpg","tags":"","background":"http://i0.hdslb.com/bfs/live/room_bg/a196943e9bbb62db1989a41cbb3ebcbf4bcf4a7b.jpg","description":"<div style=\"background: url('https://puu.sh/EPVGG/41eb2dd77d.jpg') no-repeat; width: 1120px; height: 566px;\">\n<p><img style=\"position: absolute; left: -45px; top.bilibililike.top.bilibililike.top: -28px;\" src=\"https://puu.sh/EQ1tw/5422b58d4c.png=\" width=\"233\" height=\"199\"><\/p>\n<p><img style=\"position: absolute; left: 880px; top.bilibililike.top.bilibililike.top: -22px;\" src=\"https://puu.sh/EQ14x/12592e3be3.png=\" width=\"400\" height=\"400\"><\/p>\n<p><img style=\"position: absolute; left: -80px; top.bilibililike.top.bilibililike.top: -84px;\" src=\"https://puu.sh/EPVam/deca1d2975.png=\" width=\"540\" height=\"540\"><\/p>\n<p><a href=\"https://space.bilibili.com/443305053/\" target=\"_blank\"><img style=\"position: absolute; left: 26px; top.bilibililike.top.bilibililike.top: 100px;\" src=\"https://puu.sh/EPGor/7cf8d22333.png\" width=\"115\" height=\"115\"><\/a><\/p>\n<p><a href=\"https://twitter.com/usadapekora\" target=\"_blank\"><img style=\"position: absolute; left: 97px; top.bilibililike.top.bilibililike.top: 15px;\" src=\"https://puu.sh/EPGoq/c6b8752c1f.png\" width=\"115\" height=\"115\"><\/a><\/p>\n<p><a href=\"https://www.youtube.com/channel/UC1DCedRgGHBdm81E1llLhOQ\" target=\"_blank\"><img style=\"position: absolute; left: 202px; top.bilibililike.top.bilibililike.top: -18px;\" src=\"https://puu.sh/EPGos/f1bab57dca.png\" width=\"115\" height=\"115\"><\/a><\/p>\n<p style=\"text-align: center;\"><span style=\"font-family: STHupo; font-size: x-large; text-shadow: 1px 1px 1px #ffffff;\">                                     <\/span><\/p>\n<p style=\"text-align: justify;\"><span style=\"font-family: STHupo; font-size: x-large; text-shadow: 1px 1px 1px #ffffff;\">                                              <\/span><span style=\"font-family: STHupo; font-size: x-large; text-shadow: 1px 1px 1px #ffffff;\">こんぺこ～！这里是Hololive三期生兔田佩克拉peko哟！<\/span><\/p>\n<p style=\"text-align: center;\"> <\/p>\n<p style=\"text-align: justify;\">                                                                                                               <span style=\"font-family: STHupo; font-size: medium; text-shadow: 1px 1px 1px #ffffff;\">直播间背景画师<\/span>：<a href=\"https://space.bilibili.com/22470348\" target=\"_blank\"><span style=\"font-family: STHupo; font-size: large;\">Snozaki筱崎<\/span><\/a><\/p>\n<\/div>","online":4280,"live_status":0,"live_start_time":0,"live_screen_type":0,"lock_status":0,"lock_time":0,"hidden_status":0,"hidden_time":0,"area_id":199,"area_name":"虚拟主播","parent_area_id":1,"parent_area_name":"娱乐","keyframe":"http://i0.hdslb.com/bfs/live/21560356.jpg?01191406","special_type":0,"up_session":"","pk_status":0,"pendants":{"frame":{"name":"","position":0,"value":"","desc":""},"badge":null},"on_voice_join":0,"tv_screen_on":1,"room_type":{"2-3":0,"4-1":1}},"anchor_info":{"base_info":{"uname":"兔田佩克拉Official","face":"http://i0.hdslb.com/bfs/face/9672c49fe142984f2f90d8937352fa1d7f77f629.jpg","gender":"女","official_info":{"role":0,"title":"bilibili直播签约主播","desc":""}},"live_info":{"level":28,"level_color":10512625},"relation_info":{"attention":129526}},"tab_info":[{"type":"interaction","desc":"互动","url":"","status":1,"order":100,"default":1,"default_sub_tab":"","sub_tab":[]},{"type":"up-tab","desc":"主播","url":"","status":1,"order":200,"default":0,"default_sub_tab":"video","sub_tab":[{"type":"video","desc":"视频","url":"","status":1,"order":201,"documents":"","rank_name":"","default_sub_tab":"","grand_tab":[]},{"type":"dynamic","desc":"动态","url":"","status":1,"order":202,"documents":"","rank_name":"","default_sub_tab":"","grand_tab":[]}]},{"type":"contribution-rank","desc":"贡献榜","url":"","status":1,"order":300,"default":0,"default_sub_tab":"gold-rank","sub_tab":[{"type":"gold-rank","desc":"金瓜子榜","url":"","status":1,"order":302,"documents":"按最近七日的金瓜子贡献排序，最多展示前20名用户","rank_name":"","default_sub_tab":"","grand_tab":[]},{"type":"gift-rank","desc":"礼物榜","url":"","status":1,"order":303,"documents":"","rank_name":"","default_sub_tab":"today-rank","grand_tab":[{"type":"today-rank","desc":"今日榜","url":"","status":1,"order":1,"documents":"按今日的送礼积分进行排序，最多展示前50名用户","rank_name":""},{"type":"seven-rank","desc":"七日榜","url":"","status":1,"order":2,"documents":"按最近7日的送礼积分排序，最多展示前50名用户","rank_name":""}]},{"type":"fans-rank","desc":"粉丝榜","url":"","status":1,"order":304,"documents":"按粉丝勋章的等级排序，最多展示前50名用户","rank_name":"","default_sub_tab":"","grand_tab":[]}]},{"type":"guard","desc":"大航海","url":"","status":1,"order":400,"default":0,"default_sub_tab":"","sub_tab":[]},{"type":"more-live","desc":"更多直播","url":"","status":1,"order":500,"default":0,"default_sub_tab":"relative-recommend","sub_tab":[{"type":"relative-recommend","desc":"相关推荐","url":"","status":1,"order":501,"documents":"","rank_name":"","default_sub_tab":"","grand_tab":[]},{"type":"view-history-sub","desc":"观看历史","url":"","status":1,"order":502,"documents":"","rank_name":"","default_sub_tab":"","grand_tab":[]}]},{"type":"love-club","desc":"友爱社","url":"","status":0,"order":600,"default":0,"default_sub_tab":"","sub_tab":[]}],"pk_info":null,"guard_info":{"count":30,"achievement_level":1},"guard_buy_info":{"count":0,"duration":86400,"list":[]},"rankdb_info":{"rank_desc":"小时总榜","color":"#FB7299","h5_url":"https://live.bilibili.com/p/html/live-app-rankcurrent/index.html?is_live_half_webview=1&hybrid_half_ui=1,5,85p,70p,FFE293,0,30,100,10;2,2,320,100p,FFE293,0,30,100,0;4,2,320,100p,FFE293,0,30,100,0;6,5,65p,60p,FFE293,0,30,100,10;5,5,55p,60p,FFE293,0,30,100,10;3,5,85p,70p,FFE293,0,30,100,10;7,5,65p,60p,FFE293,0,30,100,10;&anchor_uid=443305053&rank_type=master_realtime_hour_room&area_hour=1&area_v2_id=199&area_v2_parent_id=1","web_url":"https://live.bilibili.com/blackboard/room-current-rank.html?rank_type=master_realtime_hour_room&area_hour=1&area_v2_id=199&area_v2_parent_id=1","timestamp":1579417463},"round_video_info":null,"anchor_reward":{"wish_open":false},"activity_banner_info":{"top.bilibililike.top.bilibililike.top":[{"id":520,"expire_hour":24,"activity_title":"BILI星球年度直播报告来啦！","title":"","cover":"https://i0.hdslb.com/bfs/live/550c640c90f916f7f418d912a43a2b7928cf224a.png","jump_url":"https://live.bilibili.com/blackboard/year-end-2019.html?is_live_full_webview=1","rank":"","color":"","is_close":1,"type":0,"rank_name":"","gift_img":"","week_gift_color":"","week_text_color":"","week_rank_color":"","is_clock_in_over":0,"gift_progress":[]},{"id":524,"expire_hour":24,"activity_title":"hololive 1st festival","title":"","cover":"https://i0.hdslb.com/bfs/live/2c0638a6562e820ebf8a9161719ccf7172caf8da.png","jump_url":"https://www.bilibili.com/blackboard/live/activity-hololive1stFes.html","rank":"","color":"","is_close":1,"type":0,"rank_name":"","gift_img":"","week_gift_color":"","week_text_color":"","week_rank_color":"","is_clock_in_over":0,"gift_progress":[]},{"id":199,"expire_hour":24,"activity_title":"周星","title":"排名","cover":"http://i0.hdslb.com/bfs/live/c81f9ec0e09bc6d5dffa4f8f583971540f36541f.png","jump_url":"https://live.bilibili.com/p/html/live-app-weekstar/index.html?is_live_half_webview=1&hybrid_biz=live-app-weekStar&hybrid_rotate_d=1&hybrid_half_ui=1,3,100p,70p,300e51,0,30,100;2,2,375,100p,300e51,0,30,100;3,3,100p,70p,300e51,0,30,100;4,2,375,100p,300e51,0,30,100;5,3,100p,70p,300e51,0,30,100;6,3,100p,70p,300e51,0,30,100;7,3,100p,70p,300e51,0,30,100&room_id=21560356&tab=task","rank":"","color":"","is_close":1,"type":1,"rank_name":"","gift_img":"","week_gift_color":"","week_text_color":"#ffffff","week_rank_color":"#ffffff","is_clock_in_over":1,"gift_progress":[{"pic":"http://i0.hdslb.com/bfs/live/5668f46bf2a0c57f943b925bdf4f2102a8464067.png","current":10,"num":30},{"pic":"http://i0.hdslb.com/bfs/live/084ff1eaa7832c4c1040772a5fec4911930bd107.png","current":5,"num":5},{"pic":"http://i0.hdslb.com/bfs/live/75a9a524ad73ce8d7bf47d9e9d61e6378fe69b1b.png","current":0,"num":1}]}],"bottom":[],"inputBanner":[],"superBanner":{"id":521,"cover":"http://i0.hdslb.com/bfs/vc/99b71c51bd4fefdcce1bcd7dfc08c2afb97efa3a.png","jump_url":"https://live.bilibili.com/blackboard/year-end-2019.html?is_live_full_webview=1","button_jump_url":"https://live.bilibili.com/blackboard/year-end-2019.html?is_live_full_webview=1"},"lol_activity":{"vote_cover":"https://i0.hdslb.com/bfs/activity-plat/static/20190930/4ae8d4def1bbff9483154866490975c2/oWyasOpox.png","guess_cover":"http://i0.hdslb.com/bfs/live/61d1c4bcce470080a5408d6c03b7b48e0a0fa8d7.png","status":0,"vote_h5_url":"https://live.bilibili.com/p/html/live-app-wishhelp/index.html?is_live_half_webview=1&hybrid_biz=live-app-wishhelp&hybrid_rotate_d=1&hybrid_half_ui=1,3,100p,360,0c1333,0,30,100;2,2,375,100p,0c1333,0,30,100;3,3,100p,360,0c1333,0,30,100;4,2,375,100p,0c1333,0,30,100;5,3,100p,360,0c1333,0,30,100;6,2,100p,360,0c1333,0,30,100;7,3,100p,360,0c1333,0,30,100;8,3,100p,360,0c1333,0,30,100;","vote_use_h5":true},"gift_banner":{"img":[],"interval":0},"revenue_banner":{"fliping_interval":8,"list":[{"id":457,"title":"每日历险","cover":"","background":"https://i0.hdslb.com/bfs/live/3e4a0885e7aa8b0497b5b8642bfc280318aff2f1.png","jump_url":"https://live.bilibili.com/p/html/live-app-daily/index.html?is_live_half_webview=1&hybrid_rotate_d=1&hybrid_half_ui=1,3,100p,70p,7b6fd8,0,30,100;2,2,375,100p,7b6fd8,0,30,100;3,3,100p,70p,7b6fd8,0,30,100;4,2,375,100p,7b6fd8,0,30,100;5,3,100p,70p,7b6fd8,0,30,100;6,3,100p,70p,7b6fd8,0,30,100;7,3,100p,70p,7b6fd8,0,30,100&room_id=21560356#/","title_color":"#FFFFFf","closeable":1,"banner_type":0,"weight":100},{"id":378,"title":"未上榜","cover":"","background":"https://i0.hdslb.com/bfs/activity-plat/static/20190904/b5e210ef68e55c042f407870de28894b/6mLB2jCQV.png","jump_url":"https://live.bilibili.com/p/html/live-app-rankcurrent/index.html?is_live_half_webview=1&hybrid_half_ui=1,5,85p,70p,FFE293,0,30,100,10;2,2,320,100p,FFE293,0,30,100,0;4,2,320,100p,FFE293,0,30,100,0;6,5,65p,60p,FFE293,0,30,100,10;5,5,55p,60p,FFE293,0,30,100,10;3,5,85p,70p,FFE293,0,30,100,10;7,5,65p,60p,FFE293,0,30,100,10;&anchor_uid=443305053&is_new_rank_container=1&area_v2_id=199&area_v2_parent_id=1&rank_type=master_realtime_hour_room&area_hour=1","title_color":"#8B5817","closeable":1,"banner_type":4,"weight":18}]}},"activity_score_info":null,"skin_info":{"id":0,"skin_config":"","start_time":0,"end_time":0,"current_time":0},"activity_lol_match_info":{"match_id":0,"status":0,"round":0,"team_info":[],"commentatorInfo":[],"vote_config":{"vote_nums":[1,10,2000],"price":1000,"status":0},"guess_info":[],"timestamp":1579417463},"battle_info":null,"switch_info":{"close_guard":false,"close_gift":false,"close_online":false},"studio_info":null,"voice_join":{"voice_join_open":0,"voice_join_status":{"room_status":0,"status":0,"uid":0,"user_name":"","head_pic":"","guard":0,"room_id":21560356,"start_at":0,"current_time":1579417463},"vocie_join_columns":{"icon_close":"https://i0.hdslb.com/bfs/live/a176d879dffe8de1586a5eb54c2a08a0c7d31392.png","icon_open":"https://i0.hdslb.com/bfs/live/70f0844c9a12d29db1e586485954290144534be9.png","icon_wait":"https://i0.hdslb.com/bfs/live/1049bb88f1e7afd839cc1de80e13228ccd5807e8.png","icon_starting":"https://i0.hdslb.com/bfs/live/948433d1647a0704f8216f017c406224f9fff518.gif"}},"super_chat":{"status":1,"jump_url":"https://live.bilibili.com/p/html/live-app-superchat2/index.html?is_live_half_webview=1&hybrid_half_ui=1,3,100p,70p,ffffff,0,30,100;2,2,375,100p,ffffff,0,30,100;3,3,100p,70p,ffffff,0,30,100;4,2,375,100p,ffffff,0,30,100;5,3,100p,60p,ffffff,0,30,100;6,3,100p,60p,ffffff,0,30,100;7,3,100p,60p,ffffff,0,30,100&is_cling_player=1","icon":"https://i0.hdslb.com/bfs/live/0a9ebd72c76e9cbede9547386dd453475d4af6fe.png","ranked_mark":0,"message_list":[]},"room_config_info":{"dm_text":"发个弹幕呗~"}}
     */

    private int code;
    private String message;
    private int ttl;
    private DataBean data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getTtl() {
        return ttl;
    }

    public void setTtl(int ttl) {
        this.ttl = ttl;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * room_info : {"uid":443305053,"room_id":21560356,"short_id":0,"title":"只狼peko","cover":"http://i0.hdslb.com/bfs/live/new_room_cover/08e1b57d53d3f2ae7f1fcccfe0aafcff065f16aa.jpg","tags":"","background":"http://i0.hdslb.com/bfs/live/room_bg/a196943e9bbb62db1989a41cbb3ebcbf4bcf4a7b.jpg","description":"<div style=\"background: url('https://puu.sh/EPVGG/41eb2dd77d.jpg') no-repeat; width: 1120px; height: 566px;\">\n<p><img style=\"position: absolute; left: -45px; top.bilibililike.top.bilibililike.top: -28px;\" src=\"https://puu.sh/EQ1tw/5422b58d4c.png=\" width=\"233\" height=\"199\"><\/p>\n<p><img style=\"position: absolute; left: 880px; top.bilibililike.top.bilibililike.top: -22px;\" src=\"https://puu.sh/EQ14x/12592e3be3.png=\" width=\"400\" height=\"400\"><\/p>\n<p><img style=\"position: absolute; left: -80px; top.bilibililike.top.bilibililike.top: -84px;\" src=\"https://puu.sh/EPVam/deca1d2975.png=\" width=\"540\" height=\"540\"><\/p>\n<p><a href=\"https://space.bilibili.com/443305053/\" target=\"_blank\"><img style=\"position: absolute; left: 26px; top.bilibililike.top.bilibililike.top: 100px;\" src=\"https://puu.sh/EPGor/7cf8d22333.png\" width=\"115\" height=\"115\"><\/a><\/p>\n<p><a href=\"https://twitter.com/usadapekora\" target=\"_blank\"><img style=\"position: absolute; left: 97px; top.bilibililike.top.bilibililike.top: 15px;\" src=\"https://puu.sh/EPGoq/c6b8752c1f.png\" width=\"115\" height=\"115\"><\/a><\/p>\n<p><a href=\"https://www.youtube.com/channel/UC1DCedRgGHBdm81E1llLhOQ\" target=\"_blank\"><img style=\"position: absolute; left: 202px; top.bilibililike.top.bilibililike.top: -18px;\" src=\"https://puu.sh/EPGos/f1bab57dca.png\" width=\"115\" height=\"115\"><\/a><\/p>\n<p style=\"text-align: center;\"><span style=\"font-family: STHupo; font-size: x-large; text-shadow: 1px 1px 1px #ffffff;\">                                     <\/span><\/p>\n<p style=\"text-align: justify;\"><span style=\"font-family: STHupo; font-size: x-large; text-shadow: 1px 1px 1px #ffffff;\">                                              <\/span><span style=\"font-family: STHupo; font-size: x-large; text-shadow: 1px 1px 1px #ffffff;\">こんぺこ～！这里是Hololive三期生兔田佩克拉peko哟！<\/span><\/p>\n<p style=\"text-align: center;\"> <\/p>\n<p style=\"text-align: justify;\">                                                                                                               <span style=\"font-family: STHupo; font-size: medium; text-shadow: 1px 1px 1px #ffffff;\">直播间背景画师<\/span>：<a href=\"https://space.bilibili.com/22470348\" target=\"_blank\"><span style=\"font-family: STHupo; font-size: large;\">Snozaki筱崎<\/span><\/a><\/p>\n<\/div>","online":4280,"live_status":0,"live_start_time":0,"live_screen_type":0,"lock_status":0,"lock_time":0,"hidden_status":0,"hidden_time":0,"area_id":199,"area_name":"虚拟主播","parent_area_id":1,"parent_area_name":"娱乐","keyframe":"http://i0.hdslb.com/bfs/live/21560356.jpg?01191406","special_type":0,"up_session":"","pk_status":0,"pendants":{"frame":{"name":"","position":0,"value":"","desc":""},"badge":null},"on_voice_join":0,"tv_screen_on":1,"room_type":{"2-3":0,"4-1":1}}
         * anchor_info : {"base_info":{"uname":"兔田佩克拉Official","face":"http://i0.hdslb.com/bfs/face/9672c49fe142984f2f90d8937352fa1d7f77f629.jpg","gender":"女","official_info":{"role":0,"title":"bilibili直播签约主播","desc":""}},"live_info":{"level":28,"level_color":10512625},"relation_info":{"attention":129526}}
         * tab_info : [{"type":"interaction","desc":"互动","url":"","status":1,"order":100,"default":1,"default_sub_tab":"","sub_tab":[]},{"type":"up-tab","desc":"主播","url":"","status":1,"order":200,"default":0,"default_sub_tab":"video","sub_tab":[{"type":"video","desc":"视频","url":"","status":1,"order":201,"documents":"","rank_name":"","default_sub_tab":"","grand_tab":[]},{"type":"dynamic","desc":"动态","url":"","status":1,"order":202,"documents":"","rank_name":"","default_sub_tab":"","grand_tab":[]}]},{"type":"contribution-rank","desc":"贡献榜","url":"","status":1,"order":300,"default":0,"default_sub_tab":"gold-rank","sub_tab":[{"type":"gold-rank","desc":"金瓜子榜","url":"","status":1,"order":302,"documents":"按最近七日的金瓜子贡献排序，最多展示前20名用户","rank_name":"","default_sub_tab":"","grand_tab":[]},{"type":"gift-rank","desc":"礼物榜","url":"","status":1,"order":303,"documents":"","rank_name":"","default_sub_tab":"today-rank","grand_tab":[{"type":"today-rank","desc":"今日榜","url":"","status":1,"order":1,"documents":"按今日的送礼积分进行排序，最多展示前50名用户","rank_name":""},{"type":"seven-rank","desc":"七日榜","url":"","status":1,"order":2,"documents":"按最近7日的送礼积分排序，最多展示前50名用户","rank_name":""}]},{"type":"fans-rank","desc":"粉丝榜","url":"","status":1,"order":304,"documents":"按粉丝勋章的等级排序，最多展示前50名用户","rank_name":"","default_sub_tab":"","grand_tab":[]}]},{"type":"guard","desc":"大航海","url":"","status":1,"order":400,"default":0,"default_sub_tab":"","sub_tab":[]},{"type":"more-live","desc":"更多直播","url":"","status":1,"order":500,"default":0,"default_sub_tab":"relative-recommend","sub_tab":[{"type":"relative-recommend","desc":"相关推荐","url":"","status":1,"order":501,"documents":"","rank_name":"","default_sub_tab":"","grand_tab":[]},{"type":"view-history-sub","desc":"观看历史","url":"","status":1,"order":502,"documents":"","rank_name":"","default_sub_tab":"","grand_tab":[]}]},{"type":"love-club","desc":"友爱社","url":"","status":0,"order":600,"default":0,"default_sub_tab":"","sub_tab":[]}]
         * pk_info : null
         * guard_info : {"count":30,"achievement_level":1}
         * guard_buy_info : {"count":0,"duration":86400,"list":[]}
         * rankdb_info : {"rank_desc":"小时总榜","color":"#FB7299","h5_url":"https://live.bilibili.com/p/html/live-app-rankcurrent/index.html?is_live_half_webview=1&hybrid_half_ui=1,5,85p,70p,FFE293,0,30,100,10;2,2,320,100p,FFE293,0,30,100,0;4,2,320,100p,FFE293,0,30,100,0;6,5,65p,60p,FFE293,0,30,100,10;5,5,55p,60p,FFE293,0,30,100,10;3,5,85p,70p,FFE293,0,30,100,10;7,5,65p,60p,FFE293,0,30,100,10;&anchor_uid=443305053&rank_type=master_realtime_hour_room&area_hour=1&area_v2_id=199&area_v2_parent_id=1","web_url":"https://live.bilibili.com/blackboard/room-current-rank.html?rank_type=master_realtime_hour_room&area_hour=1&area_v2_id=199&area_v2_parent_id=1","timestamp":1579417463}
         * round_video_info : null
         * anchor_reward : {"wish_open":false}
         * activity_banner_info : {"top.bilibililike.top.bilibililike.top":[{"id":520,"expire_hour":24,"activity_title":"BILI星球年度直播报告来啦！","title":"","cover":"https://i0.hdslb.com/bfs/live/550c640c90f916f7f418d912a43a2b7928cf224a.png","jump_url":"https://live.bilibili.com/blackboard/year-end-2019.html?is_live_full_webview=1","rank":"","color":"","is_close":1,"type":0,"rank_name":"","gift_img":"","week_gift_color":"","week_text_color":"","week_rank_color":"","is_clock_in_over":0,"gift_progress":[]},{"id":524,"expire_hour":24,"activity_title":"hololive 1st festival","title":"","cover":"https://i0.hdslb.com/bfs/live/2c0638a6562e820ebf8a9161719ccf7172caf8da.png","jump_url":"https://www.bilibili.com/blackboard/live/activity-hololive1stFes.html","rank":"","color":"","is_close":1,"type":0,"rank_name":"","gift_img":"","week_gift_color":"","week_text_color":"","week_rank_color":"","is_clock_in_over":0,"gift_progress":[]},{"id":199,"expire_hour":24,"activity_title":"周星","title":"排名","cover":"http://i0.hdslb.com/bfs/live/c81f9ec0e09bc6d5dffa4f8f583971540f36541f.png","jump_url":"https://live.bilibili.com/p/html/live-app-weekstar/index.html?is_live_half_webview=1&hybrid_biz=live-app-weekStar&hybrid_rotate_d=1&hybrid_half_ui=1,3,100p,70p,300e51,0,30,100;2,2,375,100p,300e51,0,30,100;3,3,100p,70p,300e51,0,30,100;4,2,375,100p,300e51,0,30,100;5,3,100p,70p,300e51,0,30,100;6,3,100p,70p,300e51,0,30,100;7,3,100p,70p,300e51,0,30,100&room_id=21560356&tab=task","rank":"","color":"","is_close":1,"type":1,"rank_name":"","gift_img":"","week_gift_color":"","week_text_color":"#ffffff","week_rank_color":"#ffffff","is_clock_in_over":1,"gift_progress":[{"pic":"http://i0.hdslb.com/bfs/live/5668f46bf2a0c57f943b925bdf4f2102a8464067.png","current":10,"num":30},{"pic":"http://i0.hdslb.com/bfs/live/084ff1eaa7832c4c1040772a5fec4911930bd107.png","current":5,"num":5},{"pic":"http://i0.hdslb.com/bfs/live/75a9a524ad73ce8d7bf47d9e9d61e6378fe69b1b.png","current":0,"num":1}]}],"bottom":[],"inputBanner":[],"superBanner":{"id":521,"cover":"http://i0.hdslb.com/bfs/vc/99b71c51bd4fefdcce1bcd7dfc08c2afb97efa3a.png","jump_url":"https://live.bilibili.com/blackboard/year-end-2019.html?is_live_full_webview=1","button_jump_url":"https://live.bilibili.com/blackboard/year-end-2019.html?is_live_full_webview=1"},"lol_activity":{"vote_cover":"https://i0.hdslb.com/bfs/activity-plat/static/20190930/4ae8d4def1bbff9483154866490975c2/oWyasOpox.png","guess_cover":"http://i0.hdslb.com/bfs/live/61d1c4bcce470080a5408d6c03b7b48e0a0fa8d7.png","status":0,"vote_h5_url":"https://live.bilibili.com/p/html/live-app-wishhelp/index.html?is_live_half_webview=1&hybrid_biz=live-app-wishhelp&hybrid_rotate_d=1&hybrid_half_ui=1,3,100p,360,0c1333,0,30,100;2,2,375,100p,0c1333,0,30,100;3,3,100p,360,0c1333,0,30,100;4,2,375,100p,0c1333,0,30,100;5,3,100p,360,0c1333,0,30,100;6,2,100p,360,0c1333,0,30,100;7,3,100p,360,0c1333,0,30,100;8,3,100p,360,0c1333,0,30,100;","vote_use_h5":true},"gift_banner":{"img":[],"interval":0},"revenue_banner":{"fliping_interval":8,"list":[{"id":457,"title":"每日历险","cover":"","background":"https://i0.hdslb.com/bfs/live/3e4a0885e7aa8b0497b5b8642bfc280318aff2f1.png","jump_url":"https://live.bilibili.com/p/html/live-app-daily/index.html?is_live_half_webview=1&hybrid_rotate_d=1&hybrid_half_ui=1,3,100p,70p,7b6fd8,0,30,100;2,2,375,100p,7b6fd8,0,30,100;3,3,100p,70p,7b6fd8,0,30,100;4,2,375,100p,7b6fd8,0,30,100;5,3,100p,70p,7b6fd8,0,30,100;6,3,100p,70p,7b6fd8,0,30,100;7,3,100p,70p,7b6fd8,0,30,100&room_id=21560356#/","title_color":"#FFFFFf","closeable":1,"banner_type":0,"weight":100},{"id":378,"title":"未上榜","cover":"","background":"https://i0.hdslb.com/bfs/activity-plat/static/20190904/b5e210ef68e55c042f407870de28894b/6mLB2jCQV.png","jump_url":"https://live.bilibili.com/p/html/live-app-rankcurrent/index.html?is_live_half_webview=1&hybrid_half_ui=1,5,85p,70p,FFE293,0,30,100,10;2,2,320,100p,FFE293,0,30,100,0;4,2,320,100p,FFE293,0,30,100,0;6,5,65p,60p,FFE293,0,30,100,10;5,5,55p,60p,FFE293,0,30,100,10;3,5,85p,70p,FFE293,0,30,100,10;7,5,65p,60p,FFE293,0,30,100,10;&anchor_uid=443305053&is_new_rank_container=1&area_v2_id=199&area_v2_parent_id=1&rank_type=master_realtime_hour_room&area_hour=1","title_color":"#8B5817","closeable":1,"banner_type":4,"weight":18}]}}
         * activity_score_info : null
         * skin_info : {"id":0,"skin_config":"","start_time":0,"end_time":0,"current_time":0}
         * activity_lol_match_info : {"match_id":0,"status":0,"round":0,"team_info":[],"commentatorInfo":[],"vote_config":{"vote_nums":[1,10,2000],"price":1000,"status":0},"guess_info":[],"timestamp":1579417463}
         * battle_info : null
         * switch_info : {"close_guard":false,"close_gift":false,"close_online":false}
         * studio_info : null
         * voice_join : {"voice_join_open":0,"voice_join_status":{"room_status":0,"status":0,"uid":0,"user_name":"","head_pic":"","guard":0,"room_id":21560356,"start_at":0,"current_time":1579417463},"vocie_join_columns":{"icon_close":"https://i0.hdslb.com/bfs/live/a176d879dffe8de1586a5eb54c2a08a0c7d31392.png","icon_open":"https://i0.hdslb.com/bfs/live/70f0844c9a12d29db1e586485954290144534be9.png","icon_wait":"https://i0.hdslb.com/bfs/live/1049bb88f1e7afd839cc1de80e13228ccd5807e8.png","icon_starting":"https://i0.hdslb.com/bfs/live/948433d1647a0704f8216f017c406224f9fff518.gif"}}
         * super_chat : {"status":1,"jump_url":"https://live.bilibili.com/p/html/live-app-superchat2/index.html?is_live_half_webview=1&hybrid_half_ui=1,3,100p,70p,ffffff,0,30,100;2,2,375,100p,ffffff,0,30,100;3,3,100p,70p,ffffff,0,30,100;4,2,375,100p,ffffff,0,30,100;5,3,100p,60p,ffffff,0,30,100;6,3,100p,60p,ffffff,0,30,100;7,3,100p,60p,ffffff,0,30,100&is_cling_player=1","icon":"https://i0.hdslb.com/bfs/live/0a9ebd72c76e9cbede9547386dd453475d4af6fe.png","ranked_mark":0,"message_list":[]}
         * room_config_info : {"dm_text":"发个弹幕呗~"}
         */

        private RoomInfoBean room_info;
        private AnchorInfoBean anchor_info;
        private Object pk_info;
        private GuardInfoBean guard_info;
        private GuardBuyInfoBean guard_buy_info;
        private RankdbInfoBean rankdb_info;
        private Object round_video_info;
        private AnchorRewardBean anchor_reward;
        private ActivityBannerInfoBean activity_banner_info;
        private Object activity_score_info;
        private SkinInfoBean skin_info;
        private ActivityLolMatchInfoBean activity_lol_match_info;
        private Object battle_info;
        private SwitchInfoBean switch_info;
        private Object studio_info;
        private VoiceJoinBean voice_join;
        private SuperChatBean super_chat;
        private RoomConfigInfoBean room_config_info;
        private List<TabInfoBean> tab_info;

        public RoomInfoBean getRoom_info() {
            return room_info;
        }

        public void setRoom_info(RoomInfoBean room_info) {
            this.room_info = room_info;
        }

        public AnchorInfoBean getAnchor_info() {
            return anchor_info;
        }

        public void setAnchor_info(AnchorInfoBean anchor_info) {
            this.anchor_info = anchor_info;
        }

        public Object getPk_info() {
            return pk_info;
        }

        public void setPk_info(Object pk_info) {
            this.pk_info = pk_info;
        }

        public GuardInfoBean getGuard_info() {
            return guard_info;
        }

        public void setGuard_info(GuardInfoBean guard_info) {
            this.guard_info = guard_info;
        }

        public GuardBuyInfoBean getGuard_buy_info() {
            return guard_buy_info;
        }

        public void setGuard_buy_info(GuardBuyInfoBean guard_buy_info) {
            this.guard_buy_info = guard_buy_info;
        }

        public RankdbInfoBean getRankdb_info() {
            return rankdb_info;
        }

        public void setRankdb_info(RankdbInfoBean rankdb_info) {
            this.rankdb_info = rankdb_info;
        }

        public Object getRound_video_info() {
            return round_video_info;
        }

        public void setRound_video_info(Object round_video_info) {
            this.round_video_info = round_video_info;
        }

        public AnchorRewardBean getAnchor_reward() {
            return anchor_reward;
        }

        public void setAnchor_reward(AnchorRewardBean anchor_reward) {
            this.anchor_reward = anchor_reward;
        }

        public ActivityBannerInfoBean getActivity_banner_info() {
            return activity_banner_info;
        }

        public void setActivity_banner_info(ActivityBannerInfoBean activity_banner_info) {
            this.activity_banner_info = activity_banner_info;
        }

        public Object getActivity_score_info() {
            return activity_score_info;
        }

        public void setActivity_score_info(Object activity_score_info) {
            this.activity_score_info = activity_score_info;
        }

        public SkinInfoBean getSkin_info() {
            return skin_info;
        }

        public void setSkin_info(SkinInfoBean skin_info) {
            this.skin_info = skin_info;
        }

        public ActivityLolMatchInfoBean getActivity_lol_match_info() {
            return activity_lol_match_info;
        }

        public void setActivity_lol_match_info(ActivityLolMatchInfoBean activity_lol_match_info) {
            this.activity_lol_match_info = activity_lol_match_info;
        }

        public Object getBattle_info() {
            return battle_info;
        }

        public void setBattle_info(Object battle_info) {
            this.battle_info = battle_info;
        }

        public SwitchInfoBean getSwitch_info() {
            return switch_info;
        }

        public void setSwitch_info(SwitchInfoBean switch_info) {
            this.switch_info = switch_info;
        }

        public Object getStudio_info() {
            return studio_info;
        }

        public void setStudio_info(Object studio_info) {
            this.studio_info = studio_info;
        }

        public VoiceJoinBean getVoice_join() {
            return voice_join;
        }

        public void setVoice_join(VoiceJoinBean voice_join) {
            this.voice_join = voice_join;
        }

        public SuperChatBean getSuper_chat() {
            return super_chat;
        }

        public void setSuper_chat(SuperChatBean super_chat) {
            this.super_chat = super_chat;
        }

        public RoomConfigInfoBean getRoom_config_info() {
            return room_config_info;
        }

        public void setRoom_config_info(RoomConfigInfoBean room_config_info) {
            this.room_config_info = room_config_info;
        }

        public List<TabInfoBean> getTab_info() {
            return tab_info;
        }

        public void setTab_info(List<TabInfoBean> tab_info) {
            this.tab_info = tab_info;
        }

        public static class RoomInfoBean {
            /**
             * uid : 443305053
             * room_id : 21560356
             * short_id : 0
             * title : 只狼peko
             * cover : http://i0.hdslb.com/bfs/live/new_room_cover/08e1b57d53d3f2ae7f1fcccfe0aafcff065f16aa.jpg
             * tags :
             * background : http://i0.hdslb.com/bfs/live/room_bg/a196943e9bbb62db1989a41cbb3ebcbf4bcf4a7b.jpg
             * description : <div style="background: url('https://puu.sh/EPVGG/41eb2dd77d.jpg') no-repeat; width: 1120px; height: 566px;">
             <p><img style="position: absolute; left: -45px; top.bilibililike.top.bilibililike.top: -28px;" src="https://puu.sh/EQ1tw/5422b58d4c.png=" width="233" height="199"></p>
             <p><img style="position: absolute; left: 880px; top.bilibililike.top.bilibililike.top: -22px;" src="https://puu.sh/EQ14x/12592e3be3.png=" width="400" height="400"></p>
             <p><img style="position: absolute; left: -80px; top.bilibililike.top.bilibililike.top: -84px;" src="https://puu.sh/EPVam/deca1d2975.png=" width="540" height="540"></p>
             <p><a href="https://space.bilibili.com/443305053/" target="_blank"><img style="position: absolute; left: 26px; top.bilibililike.top.bilibililike.top: 100px;" src="https://puu.sh/EPGor/7cf8d22333.png" width="115" height="115"></a></p>
             <p><a href="https://twitter.com/usadapekora" target="_blank"><img style="position: absolute; left: 97px; top.bilibililike.top.bilibililike.top: 15px;" src="https://puu.sh/EPGoq/c6b8752c1f.png" width="115" height="115"></a></p>
             <p><a href="https://www.youtube.com/channel/UC1DCedRgGHBdm81E1llLhOQ" target="_blank"><img style="position: absolute; left: 202px; top.bilibililike.top.bilibililike.top: -18px;" src="https://puu.sh/EPGos/f1bab57dca.png" width="115" height="115"></a></p>
             <p style="text-align: center;"><span style="font-family: STHupo; font-size: x-large; text-shadow: 1px 1px 1px #ffffff;">                                     </span></p>
             <p style="text-align: justify;"><span style="font-family: STHupo; font-size: x-large; text-shadow: 1px 1px 1px #ffffff;">                                              </span><span style="font-family: STHupo; font-size: x-large; text-shadow: 1px 1px 1px #ffffff;">こんぺこ～！这里是Hololive三期生兔田佩克拉peko哟！</span></p>
             <p style="text-align: center;"> </p>
             <p style="text-align: justify;">                                                                                                               <span style="font-family: STHupo; font-size: medium; text-shadow: 1px 1px 1px #ffffff;">直播间背景画师</span>：<a href="https://space.bilibili.com/22470348" target="_blank"><span style="font-family: STHupo; font-size: large;">Snozaki筱崎</span></a></p>
             </div>
             * online : 4280
             * live_status : 0
             * live_start_time : 0
             * live_screen_type : 0
             * lock_status : 0
             * lock_time : 0
             * hidden_status : 0
             * hidden_time : 0
             * area_id : 199
             * area_name : 虚拟主播
             * parent_area_id : 1
             * parent_area_name : 娱乐
             * keyframe : http://i0.hdslb.com/bfs/live/21560356.jpg?01191406
             * special_type : 0
             * up_session :
             * pk_status : 0
             * pendants : {"frame":{"name":"","position":0,"value":"","desc":""},"badge":null}
             * on_voice_join : 0
             * tv_screen_on : 1
             * room_type : {"2-3":0,"4-1":1}
             */

            private int uid;
            private int room_id;
            private int short_id;
            private String title;
            private String cover;
            private String tags;
            private String background;
            private String description;
            private int online;
            private int live_status;
            private int live_start_time;
            private int live_screen_type;
            private int lock_status;
            private int lock_time;
            private int hidden_status;
            private int hidden_time;
            private int area_id;
            private String area_name;
            private int parent_area_id;
            private String parent_area_name;
            private String keyframe;
            private int special_type;
            private String up_session;
            private int pk_status;
            private PendantsBean pendants;
            private int on_voice_join;
            private int tv_screen_on;
            private RoomTypeBean room_type;

            public int getUid() {
                return uid;
            }

            public void setUid(int uid) {
                this.uid = uid;
            }

            public int getRoom_id() {
                return room_id;
            }

            public void setRoom_id(int room_id) {
                this.room_id = room_id;
            }

            public int getShort_id() {
                return short_id;
            }

            public void setShort_id(int short_id) {
                this.short_id = short_id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getCover() {
                return cover;
            }

            public void setCover(String cover) {
                this.cover = cover;
            }

            public String getTags() {
                return tags;
            }

            public void setTags(String tags) {
                this.tags = tags;
            }

            public String getBackground() {
                return background;
            }

            public void setBackground(String background) {
                this.background = background;
            }

            public String getDescription() {
                return description;
            }

            public void setDescription(String description) {
                this.description = description;
            }

            public int getOnline() {
                return online;
            }

            public void setOnline(int online) {
                this.online = online;
            }

            public int getLive_status() {
                return live_status;
            }

            public void setLive_status(int live_status) {
                this.live_status = live_status;
            }

            public int getLive_start_time() {
                return live_start_time;
            }

            public void setLive_start_time(int live_start_time) {
                this.live_start_time = live_start_time;
            }

            public int getLive_screen_type() {
                return live_screen_type;
            }

            public void setLive_screen_type(int live_screen_type) {
                this.live_screen_type = live_screen_type;
            }

            public int getLock_status() {
                return lock_status;
            }

            public void setLock_status(int lock_status) {
                this.lock_status = lock_status;
            }

            public int getLock_time() {
                return lock_time;
            }

            public void setLock_time(int lock_time) {
                this.lock_time = lock_time;
            }

            public int getHidden_status() {
                return hidden_status;
            }

            public void setHidden_status(int hidden_status) {
                this.hidden_status = hidden_status;
            }

            public int getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(int hidden_time) {
                this.hidden_time = hidden_time;
            }

            public int getArea_id() {
                return area_id;
            }

            public void setArea_id(int area_id) {
                this.area_id = area_id;
            }

            public String getArea_name() {
                return area_name;
            }

            public void setArea_name(String area_name) {
                this.area_name = area_name;
            }

            public int getParent_area_id() {
                return parent_area_id;
            }

            public void setParent_area_id(int parent_area_id) {
                this.parent_area_id = parent_area_id;
            }

            public String getParent_area_name() {
                return parent_area_name;
            }

            public void setParent_area_name(String parent_area_name) {
                this.parent_area_name = parent_area_name;
            }

            public String getKeyframe() {
                return keyframe;
            }

            public void setKeyframe(String keyframe) {
                this.keyframe = keyframe;
            }

            public int getSpecial_type() {
                return special_type;
            }

            public void setSpecial_type(int special_type) {
                this.special_type = special_type;
            }

            public String getUp_session() {
                return up_session;
            }

            public void setUp_session(String up_session) {
                this.up_session = up_session;
            }

            public int getPk_status() {
                return pk_status;
            }

            public void setPk_status(int pk_status) {
                this.pk_status = pk_status;
            }

            public PendantsBean getPendants() {
                return pendants;
            }

            public void setPendants(PendantsBean pendants) {
                this.pendants = pendants;
            }

            public int getOn_voice_join() {
                return on_voice_join;
            }

            public void setOn_voice_join(int on_voice_join) {
                this.on_voice_join = on_voice_join;
            }

            public int getTv_screen_on() {
                return tv_screen_on;
            }

            public void setTv_screen_on(int tv_screen_on) {
                this.tv_screen_on = tv_screen_on;
            }

            public RoomTypeBean getRoom_type() {
                return room_type;
            }

            public void setRoom_type(RoomTypeBean room_type) {
                this.room_type = room_type;
            }

            public static class PendantsBean {
                /**
                 * frame : {"name":"","position":0,"value":"","desc":""}
                 * badge : null
                 */

                private FrameBean frame;
                private Object badge;

                public FrameBean getFrame() {
                    return frame;
                }

                public void setFrame(FrameBean frame) {
                    this.frame = frame;
                }

                public Object getBadge() {
                    return badge;
                }

                public void setBadge(Object badge) {
                    this.badge = badge;
                }

                public static class FrameBean {
                    /**
                     * name :
                     * position : 0
                     * value :
                     * desc :
                     */

                    private String name;
                    private int position;
                    private String value;
                    private String desc;

                    public String getName() {
                        return name;
                    }

                    public void setName(String name) {
                        this.name = name;
                    }

                    public int getPosition() {
                        return position;
                    }

                    public void setPosition(int position) {
                        this.position = position;
                    }

                    public String getValue() {
                        return value;
                    }

                    public void setValue(String value) {
                        this.value = value;
                    }

                    public String getDesc() {
                        return desc;
                    }

                    public void setDesc(String desc) {
                        this.desc = desc;
                    }
                }
            }

            public static class RoomTypeBean {
                /**
                 * 2-3 : 0
                 * 4-1 : 1
                 */

                @com.google.gson.annotations.SerializedName("2-3")
                private int _$23;
                @com.google.gson.annotations.SerializedName("4-1")
                private int _$41;

                public int get_$23() {
                    return _$23;
                }

                public void set_$23(int _$23) {
                    this._$23 = _$23;
                }

                public int get_$41() {
                    return _$41;
                }

                public void set_$41(int _$41) {
                    this._$41 = _$41;
                }
            }
        }

        public static class AnchorInfoBean {
            /**
             * base_info : {"uname":"兔田佩克拉Official","face":"http://i0.hdslb.com/bfs/face/9672c49fe142984f2f90d8937352fa1d7f77f629.jpg","gender":"女","official_info":{"role":0,"title":"bilibili直播签约主播","desc":""}}
             * live_info : {"level":28,"level_color":10512625}
             * relation_info : {"attention":129526}
             */

            private BaseInfoBean base_info;
            private LiveInfoBean live_info;
            private RelationInfoBean relation_info;

            public BaseInfoBean getBase_info() {
                return base_info;
            }

            public void setBase_info(BaseInfoBean base_info) {
                this.base_info = base_info;
            }

            public LiveInfoBean getLive_info() {
                return live_info;
            }

            public void setLive_info(LiveInfoBean live_info) {
                this.live_info = live_info;
            }

            public RelationInfoBean getRelation_info() {
                return relation_info;
            }

            public void setRelation_info(RelationInfoBean relation_info) {
                this.relation_info = relation_info;
            }

            public static class BaseInfoBean {
                /**
                 * uname : 兔田佩克拉Official
                 * face : http://i0.hdslb.com/bfs/face/9672c49fe142984f2f90d8937352fa1d7f77f629.jpg
                 * gender : 女
                 * official_info : {"role":0,"title":"bilibili直播签约主播","desc":""}
                 */

                private String uname;
                private String face;
                private String gender;
                private OfficialInfoBean official_info;

                public String getUname() {
                    return uname;
                }

                public void setUname(String uname) {
                    this.uname = uname;
                }

                public String getFace() {
                    return face;
                }

                public void setFace(String face) {
                    this.face = face;
                }

                public String getGender() {
                    return gender;
                }

                public void setGender(String gender) {
                    this.gender = gender;
                }

                public OfficialInfoBean getOfficial_info() {
                    return official_info;
                }

                public void setOfficial_info(OfficialInfoBean official_info) {
                    this.official_info = official_info;
                }

                public static class OfficialInfoBean {
                    /**
                     * role : 0
                     * title : bilibili直播签约主播
                     * desc :
                     */

                    private int role;
                    private String title;
                    private String desc;

                    public int getRole() {
                        return role;
                    }

                    public void setRole(int role) {
                        this.role = role;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getDesc() {
                        return desc;
                    }

                    public void setDesc(String desc) {
                        this.desc = desc;
                    }
                }
            }

            public static class LiveInfoBean {
                /**
                 * level : 28
                 * level_color : 10512625
                 */

                private int level;
                private int level_color;

                public int getLevel() {
                    return level;
                }

                public void setLevel(int level) {
                    this.level = level;
                }

                public int getLevel_color() {
                    return level_color;
                }

                public void setLevel_color(int level_color) {
                    this.level_color = level_color;
                }
            }

            public static class RelationInfoBean {
                /**
                 * attention : 129526
                 */

                private int attention;

                public int getAttention() {
                    return attention;
                }

                public void setAttention(int attention) {
                    this.attention = attention;
                }
            }
        }

        public static class GuardInfoBean {
            /**
             * count : 30
             * achievement_level : 1
             */

            private int count;
            private int achievement_level;

            public int getCount() {
                return count;
            }

            public void setCount(int count) {
                this.count = count;
            }

            public int getAchievement_level() {
                return achievement_level;
            }

            public void setAchievement_level(int achievement_level) {
                this.achievement_level = achievement_level;
            }
        }

        public static class GuardBuyInfoBean {
            /**
             * count : 0
             * duration : 86400
             * list : []
             */

            private int count;
            private int duration;
            private List<?> list;

            public int getCount() {
                return count;
            }

            public void setCount(int count) {
                this.count = count;
            }

            public int getDuration() {
                return duration;
            }

            public void setDuration(int duration) {
                this.duration = duration;
            }

            public List<?> getList() {
                return list;
            }

            public void setList(List<?> list) {
                this.list = list;
            }
        }

        public static class RankdbInfoBean {
            /**
             * rank_desc : 小时总榜
             * color : #FB7299
             * h5_url : https://live.bilibili.com/p/html/live-app-rankcurrent/index.html?is_live_half_webview=1&hybrid_half_ui=1,5,85p,70p,FFE293,0,30,100,10;2,2,320,100p,FFE293,0,30,100,0;4,2,320,100p,FFE293,0,30,100,0;6,5,65p,60p,FFE293,0,30,100,10;5,5,55p,60p,FFE293,0,30,100,10;3,5,85p,70p,FFE293,0,30,100,10;7,5,65p,60p,FFE293,0,30,100,10;&anchor_uid=443305053&rank_type=master_realtime_hour_room&area_hour=1&area_v2_id=199&area_v2_parent_id=1
             * web_url : https://live.bilibili.com/blackboard/room-current-rank.html?rank_type=master_realtime_hour_room&area_hour=1&area_v2_id=199&area_v2_parent_id=1
             * timestamp : 1579417463
             */

            private String rank_desc;
            private String color;
            private String h5_url;
            private String web_url;
            private int timestamp;

            public String getRank_desc() {
                return rank_desc;
            }

            public void setRank_desc(String rank_desc) {
                this.rank_desc = rank_desc;
            }

            public String getColor() {
                return color;
            }

            public void setColor(String color) {
                this.color = color;
            }

            public String getH5_url() {
                return h5_url;
            }

            public void setH5_url(String h5_url) {
                this.h5_url = h5_url;
            }

            public String getWeb_url() {
                return web_url;
            }

            public void setWeb_url(String web_url) {
                this.web_url = web_url;
            }

            public int getTimestamp() {
                return timestamp;
            }

            public void setTimestamp(int timestamp) {
                this.timestamp = timestamp;
            }
        }

        public static class AnchorRewardBean {
            /**
             * wish_open : false
             */

            private boolean wish_open;

            public boolean isWish_open() {
                return wish_open;
            }

            public void setWish_open(boolean wish_open) {
                this.wish_open = wish_open;
            }
        }

        public static class ActivityBannerInfoBean {
            /**
             * top.bilibililike.top.bilibililike.top : [{"id":520,"expire_hour":24,"activity_title":"BILI星球年度直播报告来啦！","title":"","cover":"https://i0.hdslb.com/bfs/live/550c640c90f916f7f418d912a43a2b7928cf224a.png","jump_url":"https://live.bilibili.com/blackboard/year-end-2019.html?is_live_full_webview=1","rank":"","color":"","is_close":1,"type":0,"rank_name":"","gift_img":"","week_gift_color":"","week_text_color":"","week_rank_color":"","is_clock_in_over":0,"gift_progress":[]},{"id":524,"expire_hour":24,"activity_title":"hololive 1st festival","title":"","cover":"https://i0.hdslb.com/bfs/live/2c0638a6562e820ebf8a9161719ccf7172caf8da.png","jump_url":"https://www.bilibili.com/blackboard/live/activity-hololive1stFes.html","rank":"","color":"","is_close":1,"type":0,"rank_name":"","gift_img":"","week_gift_color":"","week_text_color":"","week_rank_color":"","is_clock_in_over":0,"gift_progress":[]},{"id":199,"expire_hour":24,"activity_title":"周星","title":"排名","cover":"http://i0.hdslb.com/bfs/live/c81f9ec0e09bc6d5dffa4f8f583971540f36541f.png","jump_url":"https://live.bilibili.com/p/html/live-app-weekstar/index.html?is_live_half_webview=1&hybrid_biz=live-app-weekStar&hybrid_rotate_d=1&hybrid_half_ui=1,3,100p,70p,300e51,0,30,100;2,2,375,100p,300e51,0,30,100;3,3,100p,70p,300e51,0,30,100;4,2,375,100p,300e51,0,30,100;5,3,100p,70p,300e51,0,30,100;6,3,100p,70p,300e51,0,30,100;7,3,100p,70p,300e51,0,30,100&room_id=21560356&tab=task","rank":"","color":"","is_close":1,"type":1,"rank_name":"","gift_img":"","week_gift_color":"","week_text_color":"#ffffff","week_rank_color":"#ffffff","is_clock_in_over":1,"gift_progress":[{"pic":"http://i0.hdslb.com/bfs/live/5668f46bf2a0c57f943b925bdf4f2102a8464067.png","current":10,"num":30},{"pic":"http://i0.hdslb.com/bfs/live/084ff1eaa7832c4c1040772a5fec4911930bd107.png","current":5,"num":5},{"pic":"http://i0.hdslb.com/bfs/live/75a9a524ad73ce8d7bf47d9e9d61e6378fe69b1b.png","current":0,"num":1}]}]
             * bottom : []
             * inputBanner : []
             * superBanner : {"id":521,"cover":"http://i0.hdslb.com/bfs/vc/99b71c51bd4fefdcce1bcd7dfc08c2afb97efa3a.png","jump_url":"https://live.bilibili.com/blackboard/year-end-2019.html?is_live_full_webview=1","button_jump_url":"https://live.bilibili.com/blackboard/year-end-2019.html?is_live_full_webview=1"}
             * lol_activity : {"vote_cover":"https://i0.hdslb.com/bfs/activity-plat/static/20190930/4ae8d4def1bbff9483154866490975c2/oWyasOpox.png","guess_cover":"http://i0.hdslb.com/bfs/live/61d1c4bcce470080a5408d6c03b7b48e0a0fa8d7.png","status":0,"vote_h5_url":"https://live.bilibili.com/p/html/live-app-wishhelp/index.html?is_live_half_webview=1&hybrid_biz=live-app-wishhelp&hybrid_rotate_d=1&hybrid_half_ui=1,3,100p,360,0c1333,0,30,100;2,2,375,100p,0c1333,0,30,100;3,3,100p,360,0c1333,0,30,100;4,2,375,100p,0c1333,0,30,100;5,3,100p,360,0c1333,0,30,100;6,2,100p,360,0c1333,0,30,100;7,3,100p,360,0c1333,0,30,100;8,3,100p,360,0c1333,0,30,100;","vote_use_h5":true}
             * gift_banner : {"img":[],"interval":0}
             * revenue_banner : {"fliping_interval":8,"list":[{"id":457,"title":"每日历险","cover":"","background":"https://i0.hdslb.com/bfs/live/3e4a0885e7aa8b0497b5b8642bfc280318aff2f1.png","jump_url":"https://live.bilibili.com/p/html/live-app-daily/index.html?is_live_half_webview=1&hybrid_rotate_d=1&hybrid_half_ui=1,3,100p,70p,7b6fd8,0,30,100;2,2,375,100p,7b6fd8,0,30,100;3,3,100p,70p,7b6fd8,0,30,100;4,2,375,100p,7b6fd8,0,30,100;5,3,100p,70p,7b6fd8,0,30,100;6,3,100p,70p,7b6fd8,0,30,100;7,3,100p,70p,7b6fd8,0,30,100&room_id=21560356#/","title_color":"#FFFFFf","closeable":1,"banner_type":0,"weight":100},{"id":378,"title":"未上榜","cover":"","background":"https://i0.hdslb.com/bfs/activity-plat/static/20190904/b5e210ef68e55c042f407870de28894b/6mLB2jCQV.png","jump_url":"https://live.bilibili.com/p/html/live-app-rankcurrent/index.html?is_live_half_webview=1&hybrid_half_ui=1,5,85p,70p,FFE293,0,30,100,10;2,2,320,100p,FFE293,0,30,100,0;4,2,320,100p,FFE293,0,30,100,0;6,5,65p,60p,FFE293,0,30,100,10;5,5,55p,60p,FFE293,0,30,100,10;3,5,85p,70p,FFE293,0,30,100,10;7,5,65p,60p,FFE293,0,30,100,10;&anchor_uid=443305053&is_new_rank_container=1&area_v2_id=199&area_v2_parent_id=1&rank_type=master_realtime_hour_room&area_hour=1","title_color":"#8B5817","closeable":1,"banner_type":4,"weight":18}]}
             */

            private SuperBannerBean superBanner;
            private LolActivityBean lol_activity;
            private GiftBannerBean gift_banner;
            private RevenueBannerBean revenue_banner;
            private List<TopBean> top;
            private List<?> bottom;
            private List<?> inputBanner;

            public SuperBannerBean getSuperBanner() {
                return superBanner;
            }

            public void setSuperBanner(SuperBannerBean superBanner) {
                this.superBanner = superBanner;
            }

            public LolActivityBean getLol_activity() {
                return lol_activity;
            }

            public void setLol_activity(LolActivityBean lol_activity) {
                this.lol_activity = lol_activity;
            }

            public GiftBannerBean getGift_banner() {
                return gift_banner;
            }

            public void setGift_banner(GiftBannerBean gift_banner) {
                this.gift_banner = gift_banner;
            }

            public RevenueBannerBean getRevenue_banner() {
                return revenue_banner;
            }

            public void setRevenue_banner(RevenueBannerBean revenue_banner) {
                this.revenue_banner = revenue_banner;
            }

            public List<TopBean> getTop() {
                return top;
            }

            public void setTop(List<TopBean> top) {
                this.top = top;
            }

            public List<?> getBottom() {
                return bottom;
            }

            public void setBottom(List<?> bottom) {
                this.bottom = bottom;
            }

            public List<?> getInputBanner() {
                return inputBanner;
            }

            public void setInputBanner(List<?> inputBanner) {
                this.inputBanner = inputBanner;
            }

            public static class SuperBannerBean {
                /**
                 * id : 521
                 * cover : http://i0.hdslb.com/bfs/vc/99b71c51bd4fefdcce1bcd7dfc08c2afb97efa3a.png
                 * jump_url : https://live.bilibili.com/blackboard/year-end-2019.html?is_live_full_webview=1
                 * button_jump_url : https://live.bilibili.com/blackboard/year-end-2019.html?is_live_full_webview=1
                 */

                private int id;
                private String cover;
                private String jump_url;
                private String button_jump_url;

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }

                public String getCover() {
                    return cover;
                }

                public void setCover(String cover) {
                    this.cover = cover;
                }

                public String getJump_url() {
                    return jump_url;
                }

                public void setJump_url(String jump_url) {
                    this.jump_url = jump_url;
                }

                public String getButton_jump_url() {
                    return button_jump_url;
                }

                public void setButton_jump_url(String button_jump_url) {
                    this.button_jump_url = button_jump_url;
                }
            }

            public static class LolActivityBean {
                /**
                 * vote_cover : https://i0.hdslb.com/bfs/activity-plat/static/20190930/4ae8d4def1bbff9483154866490975c2/oWyasOpox.png
                 * guess_cover : http://i0.hdslb.com/bfs/live/61d1c4bcce470080a5408d6c03b7b48e0a0fa8d7.png
                 * status : 0
                 * vote_h5_url : https://live.bilibili.com/p/html/live-app-wishhelp/index.html?is_live_half_webview=1&hybrid_biz=live-app-wishhelp&hybrid_rotate_d=1&hybrid_half_ui=1,3,100p,360,0c1333,0,30,100;2,2,375,100p,0c1333,0,30,100;3,3,100p,360,0c1333,0,30,100;4,2,375,100p,0c1333,0,30,100;5,3,100p,360,0c1333,0,30,100;6,2,100p,360,0c1333,0,30,100;7,3,100p,360,0c1333,0,30,100;8,3,100p,360,0c1333,0,30,100;
                 * vote_use_h5 : true
                 */

                private String vote_cover;
                private String guess_cover;
                private int status;
                private String vote_h5_url;
                private boolean vote_use_h5;

                public String getVote_cover() {
                    return vote_cover;
                }

                public void setVote_cover(String vote_cover) {
                    this.vote_cover = vote_cover;
                }

                public String getGuess_cover() {
                    return guess_cover;
                }

                public void setGuess_cover(String guess_cover) {
                    this.guess_cover = guess_cover;
                }

                public int getStatus() {
                    return status;
                }

                public void setStatus(int status) {
                    this.status = status;
                }

                public String getVote_h5_url() {
                    return vote_h5_url;
                }

                public void setVote_h5_url(String vote_h5_url) {
                    this.vote_h5_url = vote_h5_url;
                }

                public boolean isVote_use_h5() {
                    return vote_use_h5;
                }

                public void setVote_use_h5(boolean vote_use_h5) {
                    this.vote_use_h5 = vote_use_h5;
                }
            }

            public static class GiftBannerBean {
                /**
                 * img : []
                 * interval : 0
                 */

                private int interval;
                private List<?> img;

                public int getInterval() {
                    return interval;
                }

                public void setInterval(int interval) {
                    this.interval = interval;
                }

                public List<?> getImg() {
                    return img;
                }

                public void setImg(List<?> img) {
                    this.img = img;
                }
            }

            public static class RevenueBannerBean {
                /**
                 * fliping_interval : 8
                 * list : [{"id":457,"title":"每日历险","cover":"","background":"https://i0.hdslb.com/bfs/live/3e4a0885e7aa8b0497b5b8642bfc280318aff2f1.png","jump_url":"https://live.bilibili.com/p/html/live-app-daily/index.html?is_live_half_webview=1&hybrid_rotate_d=1&hybrid_half_ui=1,3,100p,70p,7b6fd8,0,30,100;2,2,375,100p,7b6fd8,0,30,100;3,3,100p,70p,7b6fd8,0,30,100;4,2,375,100p,7b6fd8,0,30,100;5,3,100p,70p,7b6fd8,0,30,100;6,3,100p,70p,7b6fd8,0,30,100;7,3,100p,70p,7b6fd8,0,30,100&room_id=21560356#/","title_color":"#FFFFFf","closeable":1,"banner_type":0,"weight":100},{"id":378,"title":"未上榜","cover":"","background":"https://i0.hdslb.com/bfs/activity-plat/static/20190904/b5e210ef68e55c042f407870de28894b/6mLB2jCQV.png","jump_url":"https://live.bilibili.com/p/html/live-app-rankcurrent/index.html?is_live_half_webview=1&hybrid_half_ui=1,5,85p,70p,FFE293,0,30,100,10;2,2,320,100p,FFE293,0,30,100,0;4,2,320,100p,FFE293,0,30,100,0;6,5,65p,60p,FFE293,0,30,100,10;5,5,55p,60p,FFE293,0,30,100,10;3,5,85p,70p,FFE293,0,30,100,10;7,5,65p,60p,FFE293,0,30,100,10;&anchor_uid=443305053&is_new_rank_container=1&area_v2_id=199&area_v2_parent_id=1&rank_type=master_realtime_hour_room&area_hour=1","title_color":"#8B5817","closeable":1,"banner_type":4,"weight":18}]
                 */

                private int fliping_interval;
                private List<ListBean> list;

                public int getFliping_interval() {
                    return fliping_interval;
                }

                public void setFliping_interval(int fliping_interval) {
                    this.fliping_interval = fliping_interval;
                }

                public List<ListBean> getList() {
                    return list;
                }

                public void setList(List<ListBean> list) {
                    this.list = list;
                }

                public static class ListBean {
                    /**
                     * id : 457
                     * title : 每日历险
                     * cover :
                     * background : https://i0.hdslb.com/bfs/live/3e4a0885e7aa8b0497b5b8642bfc280318aff2f1.png
                     * jump_url : https://live.bilibili.com/p/html/live-app-daily/index.html?is_live_half_webview=1&hybrid_rotate_d=1&hybrid_half_ui=1,3,100p,70p,7b6fd8,0,30,100;2,2,375,100p,7b6fd8,0,30,100;3,3,100p,70p,7b6fd8,0,30,100;4,2,375,100p,7b6fd8,0,30,100;5,3,100p,70p,7b6fd8,0,30,100;6,3,100p,70p,7b6fd8,0,30,100;7,3,100p,70p,7b6fd8,0,30,100&room_id=21560356#/
                     * title_color : #FFFFFf
                     * closeable : 1
                     * banner_type : 0
                     * weight : 100
                     */

                    private int id;
                    private String title;
                    private String cover;
                    private String background;
                    private String jump_url;
                    private String title_color;
                    private int closeable;
                    private int banner_type;
                    private int weight;

                    public int getId() {
                        return id;
                    }

                    public void setId(int id) {
                        this.id = id;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getCover() {
                        return cover;
                    }

                    public void setCover(String cover) {
                        this.cover = cover;
                    }

                    public String getBackground() {
                        return background;
                    }

                    public void setBackground(String background) {
                        this.background = background;
                    }

                    public String getJump_url() {
                        return jump_url;
                    }

                    public void setJump_url(String jump_url) {
                        this.jump_url = jump_url;
                    }

                    public String getTitle_color() {
                        return title_color;
                    }

                    public void setTitle_color(String title_color) {
                        this.title_color = title_color;
                    }

                    public int getCloseable() {
                        return closeable;
                    }

                    public void setCloseable(int closeable) {
                        this.closeable = closeable;
                    }

                    public int getBanner_type() {
                        return banner_type;
                    }

                    public void setBanner_type(int banner_type) {
                        this.banner_type = banner_type;
                    }

                    public int getWeight() {
                        return weight;
                    }

                    public void setWeight(int weight) {
                        this.weight = weight;
                    }
                }
            }

            public static class TopBean {
                /**
                 * id : 520
                 * expire_hour : 24
                 * activity_title : BILI星球年度直播报告来啦！
                 * title :
                 * cover : https://i0.hdslb.com/bfs/live/550c640c90f916f7f418d912a43a2b7928cf224a.png
                 * jump_url : https://live.bilibili.com/blackboard/year-end-2019.html?is_live_full_webview=1
                 * rank :
                 * color :
                 * is_close : 1
                 * type : 0
                 * rank_name :
                 * gift_img :
                 * week_gift_color :
                 * week_text_color :
                 * week_rank_color :
                 * is_clock_in_over : 0
                 * gift_progress : []
                 */

                private int id;
                private int expire_hour;
                private String activity_title;
                private String title;
                private String cover;
                private String jump_url;
                private String rank;
                private String color;
                private int is_close;
                private int type;
                private String rank_name;
                private String gift_img;
                private String week_gift_color;
                private String week_text_color;
                private String week_rank_color;
                private int is_clock_in_over;
                private List<?> gift_progress;

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }

                public int getExpire_hour() {
                    return expire_hour;
                }

                public void setExpire_hour(int expire_hour) {
                    this.expire_hour = expire_hour;
                }

                public String getActivity_title() {
                    return activity_title;
                }

                public void setActivity_title(String activity_title) {
                    this.activity_title = activity_title;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getCover() {
                    return cover;
                }

                public void setCover(String cover) {
                    this.cover = cover;
                }

                public String getJump_url() {
                    return jump_url;
                }

                public void setJump_url(String jump_url) {
                    this.jump_url = jump_url;
                }

                public String getRank() {
                    return rank;
                }

                public void setRank(String rank) {
                    this.rank = rank;
                }

                public String getColor() {
                    return color;
                }

                public void setColor(String color) {
                    this.color = color;
                }

                public int getIs_close() {
                    return is_close;
                }

                public void setIs_close(int is_close) {
                    this.is_close = is_close;
                }

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }

                public String getRank_name() {
                    return rank_name;
                }

                public void setRank_name(String rank_name) {
                    this.rank_name = rank_name;
                }

                public String getGift_img() {
                    return gift_img;
                }

                public void setGift_img(String gift_img) {
                    this.gift_img = gift_img;
                }

                public String getWeek_gift_color() {
                    return week_gift_color;
                }

                public void setWeek_gift_color(String week_gift_color) {
                    this.week_gift_color = week_gift_color;
                }

                public String getWeek_text_color() {
                    return week_text_color;
                }

                public void setWeek_text_color(String week_text_color) {
                    this.week_text_color = week_text_color;
                }

                public String getWeek_rank_color() {
                    return week_rank_color;
                }

                public void setWeek_rank_color(String week_rank_color) {
                    this.week_rank_color = week_rank_color;
                }

                public int getIs_clock_in_over() {
                    return is_clock_in_over;
                }

                public void setIs_clock_in_over(int is_clock_in_over) {
                    this.is_clock_in_over = is_clock_in_over;
                }

                public List<?> getGift_progress() {
                    return gift_progress;
                }

                public void setGift_progress(List<?> gift_progress) {
                    this.gift_progress = gift_progress;
                }
            }
        }

        public static class SkinInfoBean {
            /**
             * id : 0
             * skin_config :
             * start_time : 0
             * end_time : 0
             * current_time : 0
             */

            private int id;
            private String skin_config;
            private int start_time;
            private int end_time;
            private int current_time;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getSkin_config() {
                return skin_config;
            }

            public void setSkin_config(String skin_config) {
                this.skin_config = skin_config;
            }

            public int getStart_time() {
                return start_time;
            }

            public void setStart_time(int start_time) {
                this.start_time = start_time;
            }

            public int getEnd_time() {
                return end_time;
            }

            public void setEnd_time(int end_time) {
                this.end_time = end_time;
            }

            public int getCurrent_time() {
                return current_time;
            }

            public void setCurrent_time(int current_time) {
                this.current_time = current_time;
            }
        }

        public static class ActivityLolMatchInfoBean {
            /**
             * match_id : 0
             * status : 0
             * round : 0
             * team_info : []
             * commentatorInfo : []
             * vote_config : {"vote_nums":[1,10,2000],"price":1000,"status":0}
             * guess_info : []
             * timestamp : 1579417463
             */

            private int match_id;
            private int status;
            private int round;
            private VoteConfigBean vote_config;
            private int timestamp;
            private List<?> team_info;
            private List<?> commentatorInfo;
            private List<?> guess_info;

            public int getMatch_id() {
                return match_id;
            }

            public void setMatch_id(int match_id) {
                this.match_id = match_id;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public int getRound() {
                return round;
            }

            public void setRound(int round) {
                this.round = round;
            }

            public VoteConfigBean getVote_config() {
                return vote_config;
            }

            public void setVote_config(VoteConfigBean vote_config) {
                this.vote_config = vote_config;
            }

            public int getTimestamp() {
                return timestamp;
            }

            public void setTimestamp(int timestamp) {
                this.timestamp = timestamp;
            }

            public List<?> getTeam_info() {
                return team_info;
            }

            public void setTeam_info(List<?> team_info) {
                this.team_info = team_info;
            }

            public List<?> getCommentatorInfo() {
                return commentatorInfo;
            }

            public void setCommentatorInfo(List<?> commentatorInfo) {
                this.commentatorInfo = commentatorInfo;
            }

            public List<?> getGuess_info() {
                return guess_info;
            }

            public void setGuess_info(List<?> guess_info) {
                this.guess_info = guess_info;
            }

            public static class VoteConfigBean {
                /**
                 * vote_nums : [1,10,2000]
                 * price : 1000
                 * status : 0
                 */

                private int price;
                private int status;
                private List<Integer> vote_nums;

                public int getPrice() {
                    return price;
                }

                public void setPrice(int price) {
                    this.price = price;
                }

                public int getStatus() {
                    return status;
                }

                public void setStatus(int status) {
                    this.status = status;
                }

                public List<Integer> getVote_nums() {
                    return vote_nums;
                }

                public void setVote_nums(List<Integer> vote_nums) {
                    this.vote_nums = vote_nums;
                }
            }
        }

        public static class SwitchInfoBean {
            /**
             * close_guard : false
             * close_gift : false
             * close_online : false
             */

            private boolean close_guard;
            private boolean close_gift;
            private boolean close_online;

            public boolean isClose_guard() {
                return close_guard;
            }

            public void setClose_guard(boolean close_guard) {
                this.close_guard = close_guard;
            }

            public boolean isClose_gift() {
                return close_gift;
            }

            public void setClose_gift(boolean close_gift) {
                this.close_gift = close_gift;
            }

            public boolean isClose_online() {
                return close_online;
            }

            public void setClose_online(boolean close_online) {
                this.close_online = close_online;
            }
        }

        public static class VoiceJoinBean {
            /**
             * voice_join_open : 0
             * voice_join_status : {"room_status":0,"status":0,"uid":0,"user_name":"","head_pic":"","guard":0,"room_id":21560356,"start_at":0,"current_time":1579417463}
             * vocie_join_columns : {"icon_close":"https://i0.hdslb.com/bfs/live/a176d879dffe8de1586a5eb54c2a08a0c7d31392.png","icon_open":"https://i0.hdslb.com/bfs/live/70f0844c9a12d29db1e586485954290144534be9.png","icon_wait":"https://i0.hdslb.com/bfs/live/1049bb88f1e7afd839cc1de80e13228ccd5807e8.png","icon_starting":"https://i0.hdslb.com/bfs/live/948433d1647a0704f8216f017c406224f9fff518.gif"}
             */

            private int voice_join_open;
            private VoiceJoinStatusBean voice_join_status;
            private VocieJoinColumnsBean vocie_join_columns;

            public int getVoice_join_open() {
                return voice_join_open;
            }

            public void setVoice_join_open(int voice_join_open) {
                this.voice_join_open = voice_join_open;
            }

            public VoiceJoinStatusBean getVoice_join_status() {
                return voice_join_status;
            }

            public void setVoice_join_status(VoiceJoinStatusBean voice_join_status) {
                this.voice_join_status = voice_join_status;
            }

            public VocieJoinColumnsBean getVocie_join_columns() {
                return vocie_join_columns;
            }

            public void setVocie_join_columns(VocieJoinColumnsBean vocie_join_columns) {
                this.vocie_join_columns = vocie_join_columns;
            }

            public static class VoiceJoinStatusBean {
                /**
                 * room_status : 0
                 * status : 0
                 * uid : 0
                 * user_name :
                 * head_pic :
                 * guard : 0
                 * room_id : 21560356
                 * start_at : 0
                 * current_time : 1579417463
                 */

                private int room_status;
                private int status;
                private int uid;
                private String user_name;
                private String head_pic;
                private int guard;
                private int room_id;
                private int start_at;
                private int current_time;

                public int getRoom_status() {
                    return room_status;
                }

                public void setRoom_status(int room_status) {
                    this.room_status = room_status;
                }

                public int getStatus() {
                    return status;
                }

                public void setStatus(int status) {
                    this.status = status;
                }

                public int getUid() {
                    return uid;
                }

                public void setUid(int uid) {
                    this.uid = uid;
                }

                public String getUser_name() {
                    return user_name;
                }

                public void setUser_name(String user_name) {
                    this.user_name = user_name;
                }

                public String getHead_pic() {
                    return head_pic;
                }

                public void setHead_pic(String head_pic) {
                    this.head_pic = head_pic;
                }

                public int getGuard() {
                    return guard;
                }

                public void setGuard(int guard) {
                    this.guard = guard;
                }

                public int getRoom_id() {
                    return room_id;
                }

                public void setRoom_id(int room_id) {
                    this.room_id = room_id;
                }

                public int getStart_at() {
                    return start_at;
                }

                public void setStart_at(int start_at) {
                    this.start_at = start_at;
                }

                public int getCurrent_time() {
                    return current_time;
                }

                public void setCurrent_time(int current_time) {
                    this.current_time = current_time;
                }
            }

            public static class VocieJoinColumnsBean {
                /**
                 * icon_close : https://i0.hdslb.com/bfs/live/a176d879dffe8de1586a5eb54c2a08a0c7d31392.png
                 * icon_open : https://i0.hdslb.com/bfs/live/70f0844c9a12d29db1e586485954290144534be9.png
                 * icon_wait : https://i0.hdslb.com/bfs/live/1049bb88f1e7afd839cc1de80e13228ccd5807e8.png
                 * icon_starting : https://i0.hdslb.com/bfs/live/948433d1647a0704f8216f017c406224f9fff518.gif
                 */

                private String icon_close;
                private String icon_open;
                private String icon_wait;
                private String icon_starting;

                public String getIcon_close() {
                    return icon_close;
                }

                public void setIcon_close(String icon_close) {
                    this.icon_close = icon_close;
                }

                public String getIcon_open() {
                    return icon_open;
                }

                public void setIcon_open(String icon_open) {
                    this.icon_open = icon_open;
                }

                public String getIcon_wait() {
                    return icon_wait;
                }

                public void setIcon_wait(String icon_wait) {
                    this.icon_wait = icon_wait;
                }

                public String getIcon_starting() {
                    return icon_starting;
                }

                public void setIcon_starting(String icon_starting) {
                    this.icon_starting = icon_starting;
                }
            }
        }

        public static class SuperChatBean {
            /**
             * status : 1
             * jump_url : https://live.bilibili.com/p/html/live-app-superchat2/index.html?is_live_half_webview=1&hybrid_half_ui=1,3,100p,70p,ffffff,0,30,100;2,2,375,100p,ffffff,0,30,100;3,3,100p,70p,ffffff,0,30,100;4,2,375,100p,ffffff,0,30,100;5,3,100p,60p,ffffff,0,30,100;6,3,100p,60p,ffffff,0,30,100;7,3,100p,60p,ffffff,0,30,100&is_cling_player=1
             * icon : https://i0.hdslb.com/bfs/live/0a9ebd72c76e9cbede9547386dd453475d4af6fe.png
             * ranked_mark : 0
             * message_list : []
             */

            private int status;
            private String jump_url;
            private String icon;
            private int ranked_mark;
            private List<?> message_list;

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String getJump_url() {
                return jump_url;
            }

            public void setJump_url(String jump_url) {
                this.jump_url = jump_url;
            }

            public String getIcon() {
                return icon;
            }

            public void setIcon(String icon) {
                this.icon = icon;
            }

            public int getRanked_mark() {
                return ranked_mark;
            }

            public void setRanked_mark(int ranked_mark) {
                this.ranked_mark = ranked_mark;
            }

            public List<?> getMessage_list() {
                return message_list;
            }

            public void setMessage_list(List<?> message_list) {
                this.message_list = message_list;
            }
        }

        public static class RoomConfigInfoBean {
            /**
             * dm_text : 发个弹幕呗~
             */

            private String dm_text;

            public String getDm_text() {
                return dm_text;
            }

            public void setDm_text(String dm_text) {
                this.dm_text = dm_text;
            }
        }

        public static class TabInfoBean {
            /**
             * type : interaction
             * desc : 互动
             * url :
             * status : 1
             * order : 100
             * default : 1
             * default_sub_tab :
             * sub_tab : []
             */

            private String type;
            private String desc;
            private String url;
            private int status;
            private int order;
            @com.google.gson.annotations.SerializedName("default")
            private int defaultX;
            private String default_sub_tab;
            private List<?> sub_tab;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getDesc() {
                return desc;
            }

            public void setDesc(String desc) {
                this.desc = desc;
            }

            public String getUrl() {
                return url;
            }

            public void setUrl(String url) {
                this.url = url;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public int getOrder() {
                return order;
            }

            public void setOrder(int order) {
                this.order = order;
            }

            public int getDefaultX() {
                return defaultX;
            }

            public void setDefaultX(int defaultX) {
                this.defaultX = defaultX;
            }

            public String getDefault_sub_tab() {
                return default_sub_tab;
            }

            public void setDefault_sub_tab(String default_sub_tab) {
                this.default_sub_tab = default_sub_tab;
            }

            public List<?> getSub_tab() {
                return sub_tab;
            }

            public void setSub_tab(List<?> sub_tab) {
                this.sub_tab = sub_tab;
            }
        }
    }
}
