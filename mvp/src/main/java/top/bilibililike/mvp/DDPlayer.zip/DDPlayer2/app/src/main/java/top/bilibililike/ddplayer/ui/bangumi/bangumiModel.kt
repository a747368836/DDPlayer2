package mvp.bilibililike.player.ui.bangumi

import BaseModel


object bangumiModel: BaseModel()