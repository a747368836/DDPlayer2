package com.zhan.mvp.constant

/**
 *  @author:  hyzhan
 *  @date:    2019/8/22
 *  @desc:    TODO
 */
object Const {

    const val KT_ARMOR = "KtArmor"

    const val MESSAGE_EMPTY = "message is Empty"

    const val NETWORK_ERROR = "网络异常"
}