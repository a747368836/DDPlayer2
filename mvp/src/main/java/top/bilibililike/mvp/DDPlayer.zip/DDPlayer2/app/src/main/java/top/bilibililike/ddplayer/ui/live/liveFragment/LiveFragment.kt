package mvp.bilibililike.player.ui.live.liveFragment

import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import com.zhan.mvp.mvp.MvpFragment


import mvp.bilibililike.player.R

import mvp.bilibililike.player.ui.live.subtitle.roominfo.RoomInfoAdapter
import mvp.bilibililike.subtitle.subtitle.SubtitleService
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.recyclerview.widget.GridLayoutManager
import mvp.bilibililike.player.ui.live.subtitle.bean.RepoBean
import mvp.bilibililike.player.ui.live.subtitle.roominfo.RoomRepo
import mvp.bilibililike.player.ui.live.subtitle.utils.ToastUtil

class LiveFragment : MvpFragment<LivePresenter>(), RoomInfoAdapter.ClickCallback,ILiveView {

    lateinit var presenter: LivePresenter
    private var subtitleService: SubtitleService? = null
    private val mConnection = object : ServiceConnection {
        override fun onServiceConnected(
            className: ComponentName,
            service: IBinder
        ) {
            subtitleService = (service as SubtitleService.LocalBinder).service
        }

        override fun onServiceDisconnected(arg0: ComponentName) {

        }
    }

    override fun getLayoutId(): Int {
        return R.layout.fragment_live
    }

    override fun bindPresenter(): LivePresenter {
        presenter = LivePresenter()
        return presenter
    }

    override fun initView() {
        val adapter = RoomInfoAdapter(this)
        recyclerView.layoutManager = GridLayoutManager(context!!, 2)
        recyclerView.adapter = adapter
        val intent = Intent(context, SubtitleService::class.java)
        context.bindService(intent, mConnection, Context.BIND_AUTO_CREATE)

        RoomRepo.getLivers(object : RoomRepo.LiverCallback {
            override fun onSuccess(liverList: List<RepoBean.DataBean>) {
                adapter.refreshData(liverList)
                hideLoading()
            }

            override fun onStartLoading() {
                showLoading()
            }

            override fun onError(reason: String) {
                ToastUtil.show(reason)
            }
        })
    }



    override fun onClicked(roomId: String) {

        Log.d("点击了","点击了  $roomId")
    }


    override fun onDestroy() {
        super.onDestroy()
        context.unbindService(mConnection)
    }



}