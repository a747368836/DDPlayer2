package mvp.bilibililike.player.ui.live.liveFragment

import com.zhan.mvp.mvp.BaseContract

interface ILivePresenter : BaseContract.Presenter{
    fun getLivers(roomId:Array<String>)
}

interface ILiveView : BaseContract.View